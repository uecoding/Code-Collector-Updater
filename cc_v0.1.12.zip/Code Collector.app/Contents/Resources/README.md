# Code Collector

**Code Collector** is a native macOS application built with SwiftUI, designed to streamline the workflow of developers using AI Large Language Models (LLMs).

It serves as a bridge between your local development environment and AI tools like ChatGPT, Claude, or Gemini. Code Collector allows you to manage multiple projects, intelligently filter code files, and generate consolidated prompts containing your project structure and file contents with a single click.

## What's New
The latest version introduces a dedicated **Project Library**, a smart **Tagging System**, and a revamped workflow interface.

## Key Features

### 🗂 Project Library & Management
- **Visual Grid View:** Browse your recent projects in a beautiful grid layout with file path summaries and last-accessed dates.
- **Smart Sorting:** Sort your projects by "Recent" activity or group them by "Tags".
- **Pinning System:** Pin your most active projects to the top of the list or sidebar for instant access.
- **Context Menus:** Right-click projects to Pin/Unpin, Remove, or Assign Tags quickly.

### 🏷 Auto-Tagging & Categorization
- **Smart Auto-Tags:** The app automatically attempts to categorize projects based on their directory structure (e.g., detecting "Swift", "Python", "Javascript" from parent folders).
- **Manual Overrides:** Manually assign custom tags to any project via the context menu.
- **Visual Color Coding:** Tags are color-coded based on technology (e.g., Orange for Swift, Blue for Python, Yellow for JS) to help you visually distinguish projects.

### 🔍 Smart File Selection
- **Hierarchical Tree View:** Navigate your folder structure natively.
- **State Persistence:** The app remembers exactly which files were selected and which folders were expanded for *every* project. You can switch projects and come back exactly where you left off.
- **Advanced Filtering:** 
  - Dynamic toggle list for file extensions found in the current folder.
  - "Show All" mode to bypass filters.
  - Automatically ignores build artifacts (node_modules, .git, .DS_Store, etc.).

### ⚡️ The Collector Workflow
The main workspace is divided into three logical steps:
1.  **Prefix:** Customizable instructions for the AI (e.g., "Analyze this code...").
2.  **Files:** The active file tree selection.
3.  **Suffix:** Customizable closing instructions (e.g., "Don't change logic, just refactor...").

### 🚀 Generation & Preview
- **Instant Clipboard Copy:** Generates the prompt and copies it to the clipboard immediately.
- **Preview Mode:** Review the generated text and see the total character count before pasting it into an LLM.
- **Finder Integration:** Quickly reveal the current project folder in macOS Finder.

## How to Use

1.  **Add a Project:** Click "Open Project" in the Library or drag and drop a folder onto the window.
2.  **Library View:** Use the sidebar or the main grid to select a project. Use the picker to sort by Tags or Recents.
3.  **Configure:** 
    *   Toggle specific file extensions (e.g., `.swift`, `.py`) at the top.
    *   Check the files you want to include in the list.
    *   (Optional) Customize the **Prefix** and **Suffix** text editors.
4.  **Generate:** Click **Generate Content**. The app consolidates your selection, wraps it in your prompts, and copies it to your clipboard.
5.  **Tagging:** To organize, right-click a project card in the Library (or the sidebar) and select "Assign Tag..." to give it a category.

## Technical Details

- **Platform:** macOS (Native)
- **Framework:** SwiftUI
- **Language:** Swift
- **Persistence:** Uses `UserDefaults` and JSON encoding to save project states, bookmarks, and tagging metadata.

## Author

**Umut Erhan**  
Created on 16/10/2025